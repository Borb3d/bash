eth=$(ip a | grep enp0s3 | grep inet | cut -d '/' -f 1  | awk '{print $2}')
wlan=$(ip a | grep wlo0 | grep inet | cut -d '/' -f 1  | awk '{print $2}')
tun0=$(ip a | grep tun0 | grep inet | cut -d '/' -f 1  | awk '{print $2}')
echo "|"  ${eth} 直 ${wlan} "||"  $tun0 "|"
